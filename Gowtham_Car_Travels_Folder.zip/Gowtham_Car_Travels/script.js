// Smooth welcome message
window.addEventListener("load", () => {
    setTimeout(() => {
        alert("🚖 Welcome to Gowtham Car Travels!\nBook your ride with us today.");
    }, 800);
});

// Booking form
const form = document.querySelector("form");

if (form) {
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = form.querySelector('input[type="text"]').value;

        if (name.trim() === "") {
            alert("Please enter your name.");
            return;
        }

        alert("✅ Thank you, " + name + "!\nYour booking request has been received.\nWe will contact you soon.");

        form.reset();
    });
}

// Fade-in animation on scroll
const sections = document.querySelectorAll("section");

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = "1";
            entry.target.style.transform = "translateY(0)";
        }
    });
});

sections.forEach((section) => {
    section.style.opacity = "0";
    section.style.transform = "translateY(50px)";
    section.style.transition = "all 0.8s ease";
    observer.observe(section);
});

// Navbar shadow while scrolling
window.addEventListener("scroll", () => {
    const navbar = document.querySelector(".navbar");
    if (window.scrollY > 50) {
        navbar.style.boxShadow = "0 4px 10px rgba(255,215,0,0.4)";
    } else {
        navbar.style.boxShadow = "none";
    }
});
